package me.khoi.hiddenbuff;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.io.File;
import java.io.IOException;

public class HiddenBuffPlugin extends JavaPlugin {
    private File configFile;
    private FileConfiguration cfg;

    @Override
    public void onEnable() {
        getLogger().info("HiddenBuffPlugin enabling...");

        saveDefaultConfig();
        configFile = new File(getDataFolder(), "config.yml");
        cfg = YamlConfiguration.loadConfiguration(configFile);

        long tickInterval = cfg.getLong("tick-interval-ticks", 100L);
        String targetName = "Imnotkhoi2584";
        int strengthDuration = cfg.getInt("strength.duration-ticks", 200);
        int resistanceDuration = cfg.getInt("resistance.duration-ticks", 200);
        int strengthAmp = cfg.getInt("strength.amplifier", 1);
        int resistanceAmp = cfg.getInt("resistance.amplifier", 2);

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            Player p = Bukkit.getPlayerExact(targetName);
            if (p != null && p.isOnline()) {
                PotionEffect strength = new PotionEffect(PotionEffectType.INCREASE_DAMAGE, strengthDuration, strengthAmp, false, false, false);
                PotionEffect resistance = new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, resistanceDuration, resistanceAmp, false, false, false);
                p.addPotionEffect(strength);
                p.addPotionEffect(resistance);
            }
        }, 20L, tickInterval);

        getLogger().info("HiddenBuffPlugin enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("HiddenBuffPlugin disabled.");
    }
}
