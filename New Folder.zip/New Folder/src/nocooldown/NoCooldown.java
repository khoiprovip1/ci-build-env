package nocooldown;

import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

public class NoCooldown extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("NoCooldown enabled!");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        var p = event.getPlayer();
        AttributeInstance attr = p.getAttribute(Attribute.GENERIC_ATTACK_SPEED);

        if (attr != null) {
            attr.getModifiers().forEach(attr::removeModifier);

            AttributeModifier noCD = new AttributeModifier(
                    UUID.fromString("00000000-0000-0000-0000-000000000001"),
                    "no_cooldown",
                    100,
                    AttributeModifier.Operation.ADD_NUMBER
            );

            attr.addModifier(noCD);
        }
    }
}
